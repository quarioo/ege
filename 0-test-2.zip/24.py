s = open('24_19254.txt').readline()

l = 0
r = 1

