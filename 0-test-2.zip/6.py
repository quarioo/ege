from turtle import *

k = 6
pd()
for i in range(8):
    fd(16 * k)
    rt(90)
    fd(22 * k)
    rt(90)

pu()
fd(5 * k)
rt(90)
fd(5 * k)
lt(90)

pd()
for i in range(8):
    fd(52 * k)
    rt(90)
    fd(77 * k)
    rt(90)

exitonclick()